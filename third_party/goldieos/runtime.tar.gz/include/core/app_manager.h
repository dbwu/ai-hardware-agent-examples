#ifndef INCLUDE_APP_MANAGER_
#define INCLUDE_APP_MANAGER_

#include <string.h>
#include <stdint.h>
#include "input_service.h"

#define MAX_APP_STACK  4

typedef enum APP_TATUS_{
	APP_STATUS_NONE,
	APP_STATUS_RUNNING,
	APP_STATUS_SUSPENDED,
	APP_STATUS_EXITED,
};
// ����APP�ṹ��
typedef struct App_t{
    char app_name[32];          // Ӧ������
    void (*h_app_run)(void);      // ���к���
    void (*h_app_exit)(void);     // �˳�����
    void (*h_app_suspend)(void);  // ������
    void (*h_app_resume)(void);   // �ָ�����
    void (*h_touch_event)(int,int,int);
    void (*h_keyboard_event)(int,int);
    uint16_t* icon;             // ͼ��ָ��
    int app_status;
} App_t;

// ���֧�ֵ�APP����
#define MAX_APPS  12

// APP�������ṹ
typedef struct {
    App_t* apps[MAX_APPS];       // APP����
    int app_count;          // ��ǰAPP����
} AppManager_t;



int goldie_run_app(App_t* app);
int goldie_exit_app(App_t* app);
int goldie_suspend_app(App_t* app);
int goldie_resume_app(App_t* app);

void report_touch(int pressure,int x,int y);
void report_keyvalue(int pressure,int value);

void start_launcher_app(void);

int install_app(App_t* app);
App_t* get_app_by_name(const char* name);
App_t** get_app_list(int* count);
int get_app_count(void);
App_t* wait_app(const char* app_name);
#endif
